// This may look like C code, but it's really -*- C++ -*-
/*
 * Copyright (C) 2018 Emweb bv, Herent, Belgium.
 *
 * See the LICENSE file for terms of use.
 */
#ifndef WT_DATE_DATE_HPP
#define WT_DATE_DATE_HPP

#include "include/date/date.h"

#endif // WT_DATE_DATE_HPP
